package app;

public class Transaction {
    int id;
    String name;
    double amount;

    public Transaction(int id, String name, double amount) {
        this.id = id;
        this.name = name;
        this.amount = amount;
    }
}
